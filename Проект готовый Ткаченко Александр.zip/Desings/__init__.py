import Desings.resource
path = __file__[:-11]
