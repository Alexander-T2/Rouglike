# pyrcc5 Desings/resource.qrc -o Desings/resource.py
